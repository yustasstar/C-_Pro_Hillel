﻿namespace MyDoctorAppointment.Domain.Enums
{
	public enum IllnestTypes
	{
		EyeDisease = 1,

		Infection,

		DentalDisease,

		SkinDisease,

		Ambulance,
	}
}