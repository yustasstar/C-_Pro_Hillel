﻿namespace MyDoctorAppointment.Data.Interfaces
{
	public interface IPatientRepository
	{

	}
}
