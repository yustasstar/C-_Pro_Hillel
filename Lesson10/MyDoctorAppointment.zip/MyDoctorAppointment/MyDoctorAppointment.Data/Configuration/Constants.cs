﻿namespace MyDoctorAppointment.Data.Configuration
{
	public static class Constants
	{
		public const string JsonAppSettingsPath = "..\\..\\..\\..\\MyDoctorAppointment.Data\\Configuration\\appsettings.json";
		public const string XmlAppSettingsPath = "..\\..\\..\\..\\MyDoctorAppointment.Data\\Configuration\\appsettings.xml";
	}
}