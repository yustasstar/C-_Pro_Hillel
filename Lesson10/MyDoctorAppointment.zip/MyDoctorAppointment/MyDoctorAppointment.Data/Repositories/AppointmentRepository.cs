﻿namespace MyDoctorAppointment.Data.Repositories
{
	public class AppointmentRepository
	{
	}
}
