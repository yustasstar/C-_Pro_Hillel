﻿namespace MyDoctorAppointment.Data.Repositories
{
	public class PatientRepository
	{
	}
}
